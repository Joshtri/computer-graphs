﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rect
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Making Sharps
        Pen Blue = new Pen(Color.Blue);
        SolidBrush DarkBlue = new SolidBrush(Color.DarkBlue);
        Rectangle Rect = new Rectangle(20, 20, 220,90);
       

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            g.DrawRectangle(Blue, Rect);
            g.FillRectangle(DarkBlue,Rect);

         

        }
    }
}
