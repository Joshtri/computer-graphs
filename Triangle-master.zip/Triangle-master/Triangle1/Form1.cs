﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangle1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Draw Triangle 

        Pen Black = new Pen(Color.Black);
        SolidBrush Brown = new SolidBrush(Color.Brown);

        

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            //point 
            //Point ini akan menghasilkan garis vertical. why? idf know.
            //Point[] a = { new Point(100, 100), new Point(100,200), new Point(100,300) };

            //Point ini akan menghasilkan kosong karena value x dan y = 100 
            //Point[] a = { new Point(100, 100), new Point(100, 100), new Point(100, 100) };


            //Point ini akan menghasilkan segitiga terbalik
            //Point[] a = { new Point(100, 100), new Point(200,200), new Point(100,300) };


            //entah.
            //Point[] a = { new Point(200, 300), new Point(300, 200), new Point(400, 200) };

            // tau ini apaleh
            //Point[] a = { new Point(200, 300), new Point(200, 200), new Point(400, 200) };

            // tau ini apaleh 2
            //Point[] a = { new Point(200, 300), new Point(400, 400), new Point(400, 300) };

            // 3
            //Point[] a = { new Point(200, 300), new Point(400, 500), new Point(400, 300) };

            //intinya pythagon.
            Point[] a = { new Point(200, 200), new Point(400, 400), new Point(100, 600), new Point (500,500), new Point (400,300) };

            g.DrawPolygon(Black, a);
            g.FillPolygon(Brown, a);
            g.Dispose();




    




        }
    }
}
