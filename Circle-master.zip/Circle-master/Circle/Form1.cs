﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms; 

namespace Circle
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // khusus untuk gambar lingkaran
        Pen Red = new Pen(Color.Red);
        SolidBrush FillBlack = new SolidBrush(Color.Black);
        Rectangle Circle = new Rectangle(20,20,120,90);


        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.DrawEllipse(Red, Circle);
            g.FillEllipse(FillBlack, Circle);
        }
    }
}
